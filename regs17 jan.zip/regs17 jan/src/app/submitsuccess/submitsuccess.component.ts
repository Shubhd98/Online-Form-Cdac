import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthenticationService } from '../authentication.service';
import { RegistrationService } from '../registration.service';

@Component({
  selector: 'app-submitsuccess',
  templateUrl: './submitsuccess.component.html',
  styleUrls: ['./submitsuccess.component.css']
})
export class SubmitsuccessComponent implements OnInit {

  constructor(private _service: RegistrationService, private loginService: AuthenticationService, private _http: HttpClient, private _router: Router) { }

  ngOnInit() {
  }

}
