import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthenticationService } from '../authentication.service';
import { Personalinfo } from '../personalinfo';
import { RegistrationService } from '../registration.service';
import { User } from '../user';
import { LoginComponent } from '../login/login.component'

@Component({
  selector: 'app-loginsuccess',
  templateUrl: './loginsuccess.component.html',
  styleUrls: ['./loginsuccess.component.css']
})
export class LoginsuccessComponent implements OnInit {
  emailid: string;
  ffname: string;
  llname: string;
  faathername: string;
  doob: Date;
  geender: string;
  Aaddress: string;
  piincode: number;
  ciity: string;
  statte: string;
  imaage: File;

  personalinfo = new Personalinfo(this.emailid, this.ffname, this.llname, this.faathername, this.doob, this.geender, this.Aaddress, this.piincode,
    this.ciity, this.statte, this.imaage);

  user = new User(this.emailid);
  msg = '';

  constructor(private loginService: AuthenticationService, private _service: RegistrationService, private _router: Router) { }


  ngOnInit() {
    this.emailid = sessionStorage.getItem('emailid');
  }


  url;
  onselectFile(e) {
    if (e.target.files) {
      var reader = new FileReader();
      reader.readAsDataURL(e.target.files[0]);
      reader.onload = (event: any) => {
        this.url = event.target.result;
      }
    }
  }

  registerUser() {
    sessionStorage.setItem('fname', (this.ffname));
    sessionStorage.setItem('lname', (this.llname));
    sessionStorage.setItem('fathername', (this.faathername));
    sessionStorage.setItem('dob', (this.doob).toString());
    sessionStorage.setItem('gender', (this.geender));
    sessionStorage.setItem('address', (this.Aaddress));
    sessionStorage.setItem('city', (this.ciity));
    sessionStorage.setItem('pincode', (this.piincode).toString());
    sessionStorage.setItem('state', (this.statte));
    sessionStorage.setItem('url', (this.url));
    this._router.navigate(['/education']);

    /* this._service.fillUserFromRemote(this.personalinfo).subscribe(
      data => {
        console.log("success");
        this._router.navigate(['/previewpage']);
      },
      error => {
        console.log("error in registration");
        this.msg = " Please fill all the details correctly ";
      }
    ) */
  }





}
