import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { RegistrationService } from '../registration.service';
import { AuthenticationService } from '../authentication.service';
import { Personalinfo } from '../personalInfo';
import { User } from '../user';
import { HttpClient } from '@angular/common/http';
import { EducationDetail } from '../educationDetail';


@Component({
  selector: 'app-previewpage',
  templateUrl: './previewpage.component.html',
  styleUrls: ['./previewpage.component.css']
})
export class PreviewpageComponent implements OnInit {

  constructor(private _service: RegistrationService, private loginService: AuthenticationService, private _http: HttpClient, private _router: Router) { }

  emailid: string;
  fname: string;
  lname: string;
  fathername: string;
  dob: any;
  gender: string;
  address: string;
  pincode: any;
  city: string;
  state: string;
  image: string;
  schoolNameSSC: string;
  boardSSC: string;
  specializationSSC: string;
  percentSSC: number;
  gradeSSC: string;
  dopSSC: any;
  schoolNameHSC: string;
  boardHSC: string;
  specializationHSC: string;
  percentHSC: number;
  gradeHSC: string;
  dopHSC: any;
  qualification: string;
  stream: string;
  specializationGrad: string;
  university: string;
  college: string;
  courseDuration: string;
  dopGrad: any;
  degreePercent: number;

  personalinfo = new Personalinfo(this.emailid, this.fname, this.lname, this.fathername, this.dob, this.gender, this.address, this.pincode, this.city, this.state,
    this.image);
  educationdetail = new EducationDetail(this.schoolNameSSC,
    this.boardSSC,
    this.specializationSSC,
    this.percentSSC,
    this.gradeSSC,
    this.dopSSC,
    this.schoolNameHSC,
    this.boardHSC,
    this.specializationHSC,
    this.percentHSC,
    this.gradeHSC,
    this.dopHSC,
    this.qualification,
    this.stream,
    this.specializationGrad,
    this.university,
    this.college,
    this.courseDuration,
    this.dopGrad,
    this.degreePercent)
  user = new User(this.emailid);
  msg = '';
  ngOnInit() {
    this.personalinfo.fname = sessionStorage.getItem('fname');
    this.personalinfo.lname = sessionStorage.getItem('lname');
    this.personalinfo.fathername = sessionStorage.getItem('fathername');
    this.personalinfo.emailid = sessionStorage.getItem('emailid');
    this.personalinfo.address = sessionStorage.getItem('address');
    this.personalinfo.dob = sessionStorage.getItem('dob');
    this.personalinfo.state = sessionStorage.getItem('state');
    this.personalinfo.pincode = parseInt(sessionStorage.getItem('pincode'));
    this.personalinfo.city = sessionStorage.getItem('city');
    this.personalinfo.gender = sessionStorage.getItem('gender');
    this.personalinfo.emailid = sessionStorage.getItem('emailid');
    this.personalinfo.image = sessionStorage.getItem('url');
    this.educationdetail.schoolNameSSC = sessionStorage.getItem('schoolNameSSC');
    this.educationdetail.boardSSC = sessionStorage.getItem('boardSSC');
    this.educationdetail.specializationSSC = sessionStorage.getItem('specializationSSC');
    this.educationdetail.percentSSC = parseInt(sessionStorage.getItem('percentSSC'));
    this.educationdetail.gradeSSC = sessionStorage.getItem('gradeSSC');
    this.educationdetail.dopSSC = sessionStorage.getItem('dopSSC');
    this.educationdetail.schoolNameHSC = sessionStorage.getItem('schoolNameHSC');
    this.educationdetail.boardHSC = sessionStorage.getItem('boardHSC');
    this.educationdetail.specializationHSC = sessionStorage.getItem('specializationHSC');
    this.educationdetail.percentHSC = parseInt(sessionStorage.getItem('percentHSC'));
    this.educationdetail.gradeHSC = sessionStorage.getItem('gradeHSC');
    this.educationdetail.dopHSC = sessionStorage.getItem('dopHSC');
    this.educationdetail.qualification = sessionStorage.getItem('qualification');
    this.educationdetail.stream = sessionStorage.getItem('stream');
    this.educationdetail.specializationGrad = sessionStorage.getItem('specializationGrad');
    this.educationdetail.university = sessionStorage.getItem('university');
    this.educationdetail.college = sessionStorage.getItem('college');
    this.educationdetail.courseDuration = sessionStorage.getItem('courseDuration');
    this.educationdetail.dopGrad = sessionStorage.getItem('dopGrad');
    this.educationdetail.degreePercent = parseInt(sessionStorage.getItem('degreePercent'));

    /* this._service.fillUserFromRemote(this.personalinfo.subscribe(
      data => {
        console.log("success");
      },
      error => {
        console.log("error in registration");
        this.msg = " Please fill all the details correctly ";
      }
    ) */
  };

  editpi() {
    this._router.navigate(['/loginsuccess']);
  }
  fillUser() {
    this._service.fillUserFromRemote(this.personalinfo).subscribe(
      data => {
        console.log("success");
        this._router.navigate(['/submitsuccess']);
      },
      error => {
        console.log("error in registration");
        this.msg = " Please fill all the details correctly ";
      }
    );
  }
}