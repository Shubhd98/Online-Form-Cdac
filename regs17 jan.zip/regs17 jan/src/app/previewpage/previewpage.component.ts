import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { RegistrationService } from '../registration.service';
import { AuthenticationService } from '../authentication.service';
import { Personalinfo } from '../personalInfo';
import { User } from '../user';
import { HttpClient } from '@angular/common/http';
import { EducationDetail } from '../educationDetail';


@Component({
  selector: 'app-previewpage',
  templateUrl: './previewpage.component.html',
  styleUrls: ['./previewpage.component.css']
})
export class PreviewpageComponent implements OnInit {

  constructor(private _service: RegistrationService, private loginService: AuthenticationService, private _http: HttpClient, private _router: Router) { }

  emailid: string;
  fname: string;
  lname: string;
  fathername: string;
  dob: any;
  gender: string;
  address: string;
  pincode: any;
  city: string;
  state: string;
  image: string;
  schoolnamessc: string;
  boardssc: string;
  specializationssc: string;
  percentssc: number;
  gradessc: string;
  dopssc: any;
  schoolnamehsc: string;
  boardhsc: string;
  specializationhsc: string;
  percenthsc: number;
  gradehsc: string;
  dophsc: any;
  qualification: string;
  stream: string;
  specializationgrad: string;
  university: string;
  college: string;
  courseduration: string;
  dopgrad: any;
  degreepercent: number;

  personalinfo = new Personalinfo(this.emailid, this.fname, this.lname, this.fathername, this.dob, this.gender, this.address, this.pincode, this.city, this.state,
    this.image);
  educationdetail = new EducationDetail(this.schoolnamessc,
    this.boardssc,
    this.specializationssc,
    this.percentssc,
    this.gradessc,
    this.dopssc,
    this.schoolnamehsc,
    this.boardhsc,
    this.specializationhsc,
    this.percenthsc,
    this.gradehsc,
    this.dophsc,
    this.qualification,
    this.stream,
    this.specializationgrad,
    this.university,
    this.college,
    this.courseduration,
    this.dopgrad,
    this.degreepercent)
  user = new User(this.emailid);
  msg = '';
  ngOnInit() {
    this.personalinfo.fname = sessionStorage.getItem('fname');
    this.personalinfo.lname = sessionStorage.getItem('lname');
    this.personalinfo.fathername = sessionStorage.getItem('fathername');
    this.personalinfo.emailid = sessionStorage.getItem('emailid');
    this.personalinfo.address = sessionStorage.getItem('address');
    this.personalinfo.dob = sessionStorage.getItem('dob');
    this.personalinfo.state = sessionStorage.getItem('state');
    this.personalinfo.pincode = parseInt(sessionStorage.getItem('pincode'));
    this.personalinfo.city = sessionStorage.getItem('city');
    this.personalinfo.gender = sessionStorage.getItem('gender');
    this.personalinfo.emailid = sessionStorage.getItem('emailid');
    this.personalinfo.image = sessionStorage.getItem('url');
    this.educationdetail.schoolnamessc = sessionStorage.getItem('schoolNameSSC');
    this.educationdetail.boardssc = sessionStorage.getItem('boardSSC');
    this.educationdetail.specializationssc = sessionStorage.getItem('specializationSSC');
    this.educationdetail.percentssc = parseInt(sessionStorage.getItem('percentSSC'));
    this.educationdetail.gradessc = sessionStorage.getItem('gradeSSC');
    this.educationdetail.dopssc = sessionStorage.getItem('dopSSC');
    this.educationdetail.schoolnamehsc = sessionStorage.getItem('schoolNameHSC');
    this.educationdetail.boardhsc = sessionStorage.getItem('boardHSC');
    this.educationdetail.specializationhsc = sessionStorage.getItem('specializationHSC');
    this.educationdetail.percenthsc = parseInt(sessionStorage.getItem('percentHSC'));
    this.educationdetail.gradehsc = sessionStorage.getItem('gradeHSC');
    this.educationdetail.dophsc = sessionStorage.getItem('dopHSC');
    this.educationdetail.qualification = sessionStorage.getItem('qualification');
    this.educationdetail.stream = sessionStorage.getItem('stream');
    this.educationdetail.specializationgrad = sessionStorage.getItem('specializationGrad');
    this.educationdetail.university = sessionStorage.getItem('university');
    this.educationdetail.college = sessionStorage.getItem('college');
    this.educationdetail.courseduration = sessionStorage.getItem('courseDuration');
    this.educationdetail.dopgrad = sessionStorage.getItem('dopGrad');
    this.educationdetail.degreepercent = parseInt(sessionStorage.getItem('degreePercent'));

    /* this._service.fillUserFromRemote(this.personalinfo.subscribe(
      data => {
        console.log("success");
      },
      error => {
        console.log("error in registration");
        this.msg = " Please fill all the details correctly ";
      }
    ) */
  };

  editpi() {
    this._router.navigate(['/loginsuccess']);
  }
  fillUser() {
    this._service.fillUserFromRemote(this.personalinfo).subscribe(
      data => {
        console.log("success");
        this._router.navigate(['/submitsuccess']);
      },
      error => {
        console.log("error in registration");
        this.msg = " Please fill all the details correctly ";
      }
    );
  }
}