export class EducationDetail {
    schoolNameSSC: string;
    boardSSC: string;
    specializationSSC: string;
    percentSSC: number;
    gradeSSC: string;
    dopSSC: any;
    schoolNameHSC: string;
    boardHSC: string;
    specializationHSC: string;
    percentHSC: number;
    gradeHSC: string;
    dopHSC: any;
    qualification: string;
    stream: string;
    specializationGrad: string;
    university: string;
    college: string;
    courseDuration: string;
    dopGrad: any;
    degreePercent: number;
    constructor(schoolNameSSC,
        boardSSC,
        specializationSSC,
        percentSSC,
        gradeSSC,
        dopSSC,
        schoolNameHSC,
        boardHSC,
        specializationHSC,
        percentHSC,
        gradeHSC,
        dopHSC,
        qualification,
        stream,
        specializationGrad,
        university,
        college,
        courseDuration,
        dopGrad,
        degreePercent) {
        this.schoolNameSSC = schoolNameSSC;
        this.boardSSC = boardSSC;
        this.specializationSSC = specializationSSC;
        this.percentSSC = percentSSC;
        this.gradeSSC = gradeSSC;
        this.dopSSC = dopSSC;
        this.schoolNameHSC = schoolNameHSC;
        this.boardHSC = boardHSC;
        this.specializationHSC = specializationHSC;
        this.percentHSC = percentHSC;
        this.gradeHSC = gradeHSC;
        this.dopHSC = dopHSC;
        this.qualification = qualification;
        this.stream = stream;
        this.specializationGrad = specializationGrad;
        this.university = university;
        this.college = college;
        this.courseDuration = courseDuration;
        this.dopGrad = dopGrad;
        this.degreePercent = degreePercent;
    }

}