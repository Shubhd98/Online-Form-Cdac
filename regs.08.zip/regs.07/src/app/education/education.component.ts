import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { EducationDetail } from '../educationDetail';

@Component({
  selector: 'app-education',
  templateUrl: './education.component.html',
  styleUrls: ['./education.component.css']
})
export class EducationComponent implements OnInit {
  schoolNameSSCR: string;
  boardSSCR: string;
  specializationSSCR: string;
  percentSSCR: number;
  gradeSSCR: string;
  dopSSCR: any;
  schoolNameHSCR: string;
  boardHSCR: string;
  specializationHSCR: string;
  percentHSCR: number;
  gradeHSCR: string;
  dopHSCR: any;
  qualificationR: string;
  streamR: string;
  specializationGradR: string;
  universityR: string;
  collegeR: string;
  courseDurationR: string;
  dopGradR: any;
  degreePercentR: number;

  educationDetail = new EducationDetail(this.schoolNameSSCR,
    this.boardSSCR,
    this.specializationSSCR,
    this.percentSSCR,
    this.gradeSSCR,
    this.dopSSCR,
    this.schoolNameHSCR,
    this.boardHSCR,
    this.specializationHSCR,
    this.percentHSCR,
    this.gradeHSCR,
    this.dopHSCR,
    this.qualificationR,
    this.streamR,
    this.specializationGradR,
    this.universityR,
    this.collegeR,
    this.courseDurationR,
    this.dopGradR,
    this.degreePercentR);

  constructor(private _router: Router) { }

  ngOnInit() {
  }
  nextPreview() {
    sessionStorage.setItem('schoolNameSSC', (this.schoolNameSSCR));
    sessionStorage.setItem('boardSSC', (this.boardSSCR));
    sessionStorage.setItem('specializationSSC', (this.specializationSSCR));
    sessionStorage.setItem('percentSSC', (this.percentSSCR).toString());
    sessionStorage.setItem('gradeSSC', (this.gradeSSCR));
    sessionStorage.setItem('dopSSC', (this.dopSSCR).toString());
    sessionStorage.setItem('schoolNameHSC', (this.schoolNameHSCR));
    sessionStorage.setItem('boardHSC', (this.boardHSCR));
    sessionStorage.setItem('specializationHSC', (this.specializationHSCR));
    sessionStorage.setItem('percentHSC', (this.percentHSCR).toString());
    sessionStorage.setItem('gradeHSC', (this.gradeHSCR));
    sessionStorage.setItem('dopHSC', (this.dopHSCR).toString());
    sessionStorage.setItem('qualification', (this.qualificationR));
    sessionStorage.setItem('stream', (this.streamR));
    sessionStorage.setItem('specislizationGrad', (this.specializationGradR));
    sessionStorage.setItem('university', (this.universityR));
    sessionStorage.setItem('college', (this.collegeR));
    sessionStorage.setItem('courseDuration', (this.courseDurationR));
    sessionStorage.setItem('dopGrad', (this.dopGradR).toString());
    sessionStorage.setItem('degreePercent', (this.degreePercentR).toString());
    this._router.navigate(['/previewpage']);
  }
}
