export class Query {

   
    emailid: string;
    Fullname: string;
    msg: string;
    constructor() {
        
    }
}
