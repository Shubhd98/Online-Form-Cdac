import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Centre } from '../centre';

@Component({
  selector: 'app-findus',
  templateUrl: './findus.component.html',
  styleUrls: ['./findus.component.css']
})
export class FindusComponent implements OnInit {

  centres :any;
  city="Bangalore"
  constructor(private http:HttpClient) { }

  ngOnInit() {
    
 let resp=this.http.get("http://localhost:6071/search",this.city);
 resp.subscribe((data)=>this.centres=resp);
  }

}
