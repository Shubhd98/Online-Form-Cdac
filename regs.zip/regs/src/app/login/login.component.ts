import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthenticationService } from '../authentication.service';
import { RegistrationService } from '../registration.service';
import { User } from '../user';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  emailid: string ='';
  user = new User(this.emailid);
  validlogin = false;
  usernam: string = "validLogin";
  msg = '';
  constructor(private _service: RegistrationService, private _router: Router, private authentication: AuthenticationService) { }

  ngOnInit() {
  }



 // this.y.update(this.obj).subscribe(
 // (lk:Eraser)=>{
 // this.myfav="s"


  loginUser() {
    this._service.loginUserFromRemote(this.user).subscribe(
      (data:User) => {
        console.log("response recieved");
        this.validlogin = true;
        this.authentication.authenticate(this.validlogin, this.usernam);
        sessionStorage.setItem('emailid', (this.user.emailid));
        this._router.navigate(['/loginsuccess']);
      },
      error => {
        console.log("error");
        this.msg = "bad credentials please enter valid email id and password";
      }
    )
  }

  gotoregistration() {
    this._router.navigate(['/registration']);
  }

}
