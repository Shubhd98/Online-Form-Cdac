import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { RegistrationService } from '../registration.service';
import { AuthenticationService } from '../authentication.service';
import { Personalinfo } from '../personalInfo';
import { User } from '../user';
import { HttpClient } from '@angular/common/http';


@Component({
  selector: 'app-previewpage',
  templateUrl: './previewpage.component.html',
  styleUrls: ['./previewpage.component.css']
})
export class PreviewpageComponent implements OnInit {

  constructor(private _service: RegistrationService, private loginService: AuthenticationService, private _http: HttpClient, private _router: Router) { }

  emailid: string;
  fname: string;
  lname: string;
  fathername: string;
  dob: any;
  gender: string;
  address: string;
  pincode: any;
  city: string;
  state: string;
  degreename: string;
  university: string;
  yop: any;
  percent: any;
  image: string;

  personalinfo = new Personalinfo(this.emailid,this.fname, this.lname, this.fathername, this.dob, this.gender, this.address, this.pincode, this.city, this.state,
    this.degreename, this.university, this.yop, this.percent, this.image);
  user = new User(this.emailid);
  msg = '';
  ngOnInit() {
    this.personalinfo.fname = sessionStorage.getItem('fname');
    this.personalinfo.lname = sessionStorage.getItem('lname');
    this.personalinfo.fathername = sessionStorage.getItem('fathername');
    this.personalinfo.emailid = sessionStorage.getItem('emailid');
    this.personalinfo.address = sessionStorage.getItem('address');
    this.personalinfo.dob = sessionStorage.getItem('dob');
    this.personalinfo.state = sessionStorage.getItem('state');
    this.personalinfo.pincode = parseInt(sessionStorage.getItem('pincode'));
    this.personalinfo.city = sessionStorage.getItem('city');
    this.personalinfo.degreename = sessionStorage.getItem('degree');
    this.personalinfo.university = sessionStorage.getItem('university');
    this.personalinfo.gender = sessionStorage.getItem('gender');
    this.personalinfo.yop = parseInt(sessionStorage.getItem('yop'));
    this.personalinfo.percent = sessionStorage.getItem('percentage');
    this.personalinfo.emailid=sessionStorage.getItem('emailid');
    //this.personalinfo.image = sessionStorage.getItem('imaage');
    /* this._service.fillUserFromRemote(this.personalinfo.subscribe(
      data => {
        console.log("success");
      },
      error => {
        console.log("error in registration");
        this.msg = " Please fill all the details correctly ";
      }
    ) */
  };
  editpi() {
    this._router.navigate(['/loginsuccess']);
  }
  fillUser() {
    this._service.fillUserFromRemote(this.personalinfo).subscribe(
      data => {
        console.log("success");
      },
      error => {
        console.log("error in registration");
        this.msg = " Please fill all the details correctly ";
      }
    );
  }
}