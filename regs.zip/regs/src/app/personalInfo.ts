import { User } from "./user";

export class Personalinfo {
    id: number;
    emailid: string;
    fname: string;
    lname: string;
    fathername: string;
    dob: any;
    gender: string;
    address: string;
    pincode: number;
    city: string;
    state: string;
    degreename: string;
    university: string;
    yop: number;
    percent: any;
    image: any;
    constructor(emailid,fname, lname, fathername, dob, gender, address, pincode, city, state, degreename, university, yop, percent, image) {
        this.emailid=emailid;
        this.fname = fname;
        this.lname = lname;
        this.fathername = fathername;
        this.dob = dob;
        this.gender = gender;
        this.address = address;
        this.pincode = pincode;
        this.city = city;
        this.state = state;
        this.degreename = degreename;
        this.university = university;
        this.yop = yop;
        this.percent = percent;
        this.image = image;
    }


}