import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { User } from './user';
import { Personalinfo } from './personalInfo';
import { HttpClient } from '@angular/common/http';
import { EducationDetail } from './educationDetail';
import { Query } from './query';
import { Centre } from './centre';

@Injectable({
  providedIn: 'root'
})
export class RegistrationService {

  constructor(private _http: HttpClient) { }//dependency injection


  public loginUserFromRemote(user: User): Observable<any> {
    return this._http.post<any>("http://localhost:6071/login", user);
  }

  public registerUserFromRemote(user: User): Observable<any> {
    return this._http.post<any>("http://localhost:6071/registration", user);
  }
  public fillUserFromRemote(piinfo: Personalinfo): Observable<any> {
    return this._http.post<any>("http://localhost:6071/personalinfo", piinfo);
  }
  public fillUserFromRemoteed(ed: EducationDetail): Observable<any> {
    return this._http.post<any>("http://localhost:6071/education", ed);
  }

  public sendQueryFromRemote(query: Query): Observable<any> {
    return this._http.post<any>("http://localhost:6071/feedback", query);
  }
  public searchFromRemote(city: any): Observable<any> {
    return this._http.get("http://localhost:6071/search?x=" + city);
  }
  // public previewFromRemote(personalInfo: Personalinfo): Observable<any> {
  //   return this._http.get<any>("http://localhost:6071/ms")
  // }
}
