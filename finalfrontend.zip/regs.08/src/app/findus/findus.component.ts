import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Centre } from '../centre';
import { Router } from '@angular/router';
import { RegistrationService } from '../registration.service';

@Component({
  selector: 'app-findus',
  templateUrl: './findus.component.html',
  styleUrls: ['./findus.component.css']
})
export class FindusComponent implements OnInit {

  centres = new Centre();
  constructor(private _service: RegistrationService, private _http: HttpClient, private _router: Router) { }

  ngOnInit() {


  }
  searchdb() {
    this._service.searchFromRemote(this.centres.City).subscribe(
      data => {
        console.log("success");
        console.log(data);
        this.centres = data;
      },
      error => {
        console.log("error in search");
      }
    );
  }

}
