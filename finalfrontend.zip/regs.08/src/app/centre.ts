export class Centre {
    
    City: string;
    Centrename: string;
    Courses: string;
    constructor() {
        
    }
}
