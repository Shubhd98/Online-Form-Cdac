import { Centre } from './centre';

describe('Centre', () => {
  it('should create an instance', () => {
    expect(new Centre()).toBeTruthy();
  });
});
