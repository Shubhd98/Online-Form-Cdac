export class EducationDetail {
    schoolssc: string;
    boardssc: string;
    specializationssc: string;
    percentssc: number;
    gradessc: string;
    dopssc: any;
    schoolnamehsc: string;
    boardhsc: string;
    specializationhsc: string;
    percenthsc: number;
    gradehsc: string;
    dophsc: any;
    qualification: string;
    stream: string;
    specializationgrad: string;
    university: string;
    college: string;
    courseduration: string;
    dopgrad: any;
    degreepercent: number;
    constructor(schoolssc,
        boardssc,
        specializationssc,
        percentssc,
        gradessc,
        dopssc,
        schoolnamehsc,
        boardhsc,
        specializationhsc,
        percenthsc,
        gradehsc,
        dophsc,
        qualification,
        stream,
        specializationgrad,
        university,
        college,
        courseduration,
        dopgrad,
        degreepercent) {
        this.schoolssc = schoolssc;
        this.boardssc = boardssc;
        this.specializationssc = specializationssc;
        this.percentssc = percentssc;
        this.gradessc = gradessc;
        this.dopssc = dopssc;
        this.schoolnamehsc = schoolnamehsc;
        this.boardhsc = boardhsc;
        this.specializationhsc = specializationhsc;
        this.percenthsc = percenthsc;
        this.gradehsc = gradehsc;
        this.dophsc = dophsc;
        this.qualification = qualification;
        this.stream = stream;
        this.specializationgrad = specializationgrad;
        this.university = university;
        this.college = college;
        this.courseduration = courseduration;
        this.dopgrad = dopgrad;
        this.degreepercent = degreepercent;
    }

}