import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { EducationDetail } from '../educationDetail';

@Component({
  selector: 'app-education',
  templateUrl: './education.component.html',
  styleUrls: ['./education.component.css']
})
export class EducationComponent implements OnInit {
  schoolNameSSCR: string;
  boardSSCR: string;
  specializationSSCR: string;
  percentSSCR: number;
  gradeSSCR: string;
  dopSSCR: any;
  schoolNameHSCR: string;
  boardHSCR: string;
  specializationHSCR: string;
  percentHSCR: number;
  gradeHSCR: string;
  dopHSCR: any;
  qualificationR: string;
  streamR: string;
  specializationGradR: string;
  universityR: string;
  collegeR: string;
  courseDurationR: string;
  dopGradR: any;
  degreePercentR: number;

  educationDetail = new EducationDetail(this.schoolNameSSCR,
    this.boardSSCR,
    this.specializationSSCR,
    this.percentSSCR,
    this.gradeSSCR,
    this.dopSSCR,
    this.schoolNameHSCR,
    this.boardHSCR,
    this.specializationHSCR,
    this.percentHSCR,
    this.gradeHSCR,
    this.dopHSCR,
    this.qualificationR,
    this.streamR,
    this.specializationGradR,
    this.universityR,
    this.collegeR,
    this.courseDurationR,
    this.dopGradR,
    this.degreePercentR);

  constructor(private _router: Router) { }

  ngOnInit() {
  }
  nextPreview() {
    sessionStorage.setItem('schoolssc', (this.schoolNameSSCR));
    sessionStorage.setItem('boardssc', (this.boardSSCR));
    sessionStorage.setItem('specializationssc', (this.specializationSSCR));
    sessionStorage.setItem('percentssc', (this.percentSSCR).toString());
    sessionStorage.setItem('gradessc', (this.gradeSSCR));
    sessionStorage.setItem('dopssc', (this.dopSSCR).toString());
    sessionStorage.setItem('schoolnamehsc', (this.schoolNameHSCR));
    sessionStorage.setItem('boardhsc', (this.boardHSCR));
    sessionStorage.setItem('specializationhsc', (this.specializationHSCR));
    sessionStorage.setItem('percenthsc', (this.percentHSCR).toString());
    sessionStorage.setItem('gradehsc', (this.gradeHSCR));
    sessionStorage.setItem('dophsc', (this.dopHSCR).toString());
    sessionStorage.setItem('qualification', (this.qualificationR));
    sessionStorage.setItem('stream', (this.streamR));
    sessionStorage.setItem('specislizationgrad', (this.specializationGradR));
    sessionStorage.setItem('university', (this.universityR));
    sessionStorage.setItem('college', (this.collegeR));
    sessionStorage.setItem('courseduration', (this.courseDurationR));
    sessionStorage.setItem('dopgrad', (this.dopGradR).toString());
    sessionStorage.setItem('degreepercent', (this.degreePercentR).toString());
    this._router.navigate(['/previewpage']);
  }
}
