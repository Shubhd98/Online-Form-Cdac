import { Personalinfo } from './personalinfo';

describe('Personalinfo', () => {
  it('should create an instance', () => {
    expect(new Personalinfo()).toBeTruthy();
  });
});
