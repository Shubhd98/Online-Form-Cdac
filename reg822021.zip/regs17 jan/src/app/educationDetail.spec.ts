import { EducationDetail } from './educationDetail';

describe('EducationDetail', () => {
    it('should create an instance', () => {
        expect(new EducationDetail()).toBeTruthy();
    });
});