export class EducationDetail {
    schoolnamessc: string;
    boardssc: string;
    specializationssc: string;
    percentssc: number;
    gradessc: string;
    dopssc: any;
    schoolnamehsc: string;
    boardhsc: string;
    specializationhsc: string;
    percenthsc: number;
    gradehsc: string;
    dophsc: any;
    qualification: string;
    stream: string;
    specializationgrad: string;
    university: string;
    college: string;
    courseduration: string;
    dopgrad: any;
    degreepercent: number;
    constructor(schoolnamessc,
        boardssc,
        specializationssc,
        percentssc,
        gradessc,
        dopssc,
        schoolnamehsc,
        boardhsc,
        specializationhsc,
        percenthsc,
        gradehsc,
        dophsc,
        qualification,
        stream,
        specializationgrad,
        university,
        college,
        courseduration,
        dopgrad,
        degreepercent) {
        this.schoolnamessc = schoolnamessc;
        this.boardssc = boardssc;
        this.specializationssc = specializationssc;
        this.percentssc = percentssc;
        this.gradessc = gradessc;
        this.dopssc = dopssc;
        this.schoolnamehsc = schoolnamehsc;
        this.boardhsc = boardhsc;
        this.specializationhsc = specializationhsc;
        this.percenthsc = percenthsc;
        this.gradehsc = gradehsc;
        this.dophsc = dophsc;
        this.qualification = qualification;
        this.stream = stream;
        this.specializationgrad = specializationgrad;
        this.university = university;
        this.college = college;
        this.courseduration = courseduration;
        this.dopgrad = dopgrad;
        this.degreepercent = degreepercent;
    }

}