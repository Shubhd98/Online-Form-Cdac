import { User } from "./user";

export class Personalinfo {
    id: number;
    emailid: string;
    fname: string;
    lname: string;
    fathername: string;
    dob: any;
    gender: string;
    address: string;
    pincode: number;
    city: string;
    state: string;

    image: any;
    constructor(emailid, fname, lname, fathername, dob, gender, address, pincode, city, state, image) {
        this.emailid = emailid;
        this.fname = fname;
        this.lname = lname;
        this.fathername = fathername;
        this.dob = dob;
        this.gender = gender;
        this.address = address;
        this.pincode = pincode;
        this.city = city;
        this.state = state;
        this.image = image;
    }


}