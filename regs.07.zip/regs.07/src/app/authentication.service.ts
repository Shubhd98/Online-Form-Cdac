import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {

  constructor() { }
  authenticate(validlogin,usernam:string) {
    if (validlogin===true) {
      sessionStorage.setItem('username', usernam)
      return true;
    } else {
      return false;
    }
  }

  isUser1LoggedIn() {
    let user1 = sessionStorage.getItem('username')
    console.log(!(user1 === null))
    return !(user1 === null)
  }

  logOut() {
    sessionStorage.removeItem('username')
  }
}



