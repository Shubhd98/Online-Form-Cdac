import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthenticationService } from '../authentication.service';
import { Query } from '../query';
import { RegistrationService } from '../registration.service';

@Component({
  selector: 'app-query',
  templateUrl: './query.component.html',
  styleUrls: ['./query.component.css']
})
export class QueryComponent implements OnInit {

  query =new Query();
  constructor(private _service: RegistrationService, private _router: Router, private authentication: AuthenticationService) { }

  ngOnInit() {
  }

  sendQuery() {
    this._service.sendQueryFromRemote(this.query).subscribe(
      data => {
        console.log("query recieved");
       // this._router.navigate(['/loginsuccess']);
      },
      error => {
        console.log("error");
       // this.msg = "bad credentials please enter valid email id and password";
      }
    )
  }


}
